# Team declaration
| Name | Role |
|---|---|
| (fill in) | (fill in) |

**Models/APIs:** none by default; optional Anthropic API (wording only) when `ARES_USE_LLM=1`.
**Libraries:** FastAPI, Uvicorn, Pydantic, httpx, SQLite (stdlib), Streamlit, requests, pytest.
**Pre-existing code:** none (declare any here). AI coding tools used: Claude.
